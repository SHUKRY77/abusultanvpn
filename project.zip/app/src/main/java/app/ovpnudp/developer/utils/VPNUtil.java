package app.ovpnudp.developer.utils;
import static java.lang.Runtime.getRuntime;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

import app.ovpnudp.developer.service.*;

public class VPNUtil
{

	private static VPNUtil.VPNProtectListener Listener;

	private static OpenVPNService mService;
	public interface VPNProtectListener
	{
		boolean protectSocket(Socket socket);
	}
	public static void setVPNProtectListener(VPNProtectListener VPNProtectListener)
	{
		Listener = VPNProtectListener;
	}
	public static boolean isProtected(Socket socket)
	{
		return Listener != null ? Listener.protectSocket(socket) : false;
	}
	public static void setVPNService(OpenVPNService service)
	{
		mService = service;
	}
	public static OpenVPNService getService()
	{
		return mService;
	}
	public static String decrypt (String str)
	{
		return Utils.Parser.parseToString(str.replace(" ", "").replace("\n", ""));
	}
	public static String encrypt (String str)
	{
		return Utils.Parser.parse(str);
	}

	public static void killProcess(File fileProcBin) throws Exception {
		killProcess(fileProcBin, "-9"); // this is -KILL
	}
	public static int killProcess(File fileProcBin, String signal) throws Exception {

		int procId = -1;
		int killAttempts = 0;

		while ((procId = findProcessId(fileProcBin.getName())) != -1) {
			killAttempts++;
			String pidString = String.valueOf(procId);

			String[] cmds = {"","busybox ","toolbox "};

			for (int i = 0; i < cmds.length;i++) {
				try {
					getRuntime().exec(cmds[i] + "killall " + signal + " " + fileProcBin.getName
							());
				} catch (IOException ioe) {
				}
				try {
					getRuntime().exec(cmds[i] + "killall " + signal + " " + fileProcBin.getCanonicalPath());
				} catch (IOException ioe) {
				}
			}

			killProcess(pidString, signal);

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// ignored
			}

			if (killAttempts > 4)
				throw new Exception("Cannot kill: " + fileProcBin.getAbsolutePath());
		}

		return procId;
	}

	public static void killProcess(String pidString, String signal) throws Exception {

		String[] cmds = {"","toolbox ","busybox "};

		for (int i = 0; i < cmds.length;i++) {
			try {
				getRuntime().exec(cmds[i] + "kill " + signal + " " + pidString);
			} catch (IOException ioe) {
			//	VpnStatus.logDebug(String.format("error killing process: %s, %s", pidString, ioe.getMessage()));
			}
		}
	}
	public static int findProcessId(String command) throws IOException {

		String[] cmds = {"ps -ef","ps -A","toolbox ps"};

		for (int i = 0; i < cmds.length;i++) {
			Process procPs = getRuntime().exec(cmds[i]);

			BufferedReader reader = new BufferedReader(new InputStreamReader(procPs.getInputStream()));

			String line;
			while ((line = reader.readLine()) != null) {
				if (!line.contains("PID") && line.contains(command)) {
					String[] lineParts = line.split("\\s+");
					try {
						return Integer.parseInt(lineParts[1]); //for most devices it is the second
					} catch (NumberFormatException e) {
						return Integer.parseInt(lineParts[0]); //but for samsungs it is the first
					} finally {
						try {
							procPs.destroy();
						} catch (Exception e) {
						}
					}
				}
			}
		}

		return -1;
	}


	public static boolean saveTextFile(File file, String contents)
	{
		try {

			if (!file.exists()) {
				file.createNewFile();
			}

			FileWriter writer = new FileWriter(file, false);
			writer.write(contents);

			writer.close();

			return true;

		} catch (IOException e) {
			//	Log.d(TAG, "error writing file: " + path, e);
			e.printStackTrace();
			return false;
		}
	}
}
